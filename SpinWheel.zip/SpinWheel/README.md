# Spin Wheel Picker (Android native, Kotlin)

Native Android app (not a PWA): custom Canvas wheel, weighted options, spin animation with
tick/win sounds, vibration, history, multiple wheels, templates, dark/light theme, EN + ID strings.

## Build
1. Open this folder in Android Studio (Koala or newer) -> let Gradle sync.
2. Run on a device/emulator (minSdk 21), or Build > Build APK(s).
Command line (with Android SDK installed): `gradle assembleDebug`
Output: app/build/outputs/apk/debug/app-debug.apk
