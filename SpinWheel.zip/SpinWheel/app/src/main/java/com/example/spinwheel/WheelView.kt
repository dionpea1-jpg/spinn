package com.example.spinwheel

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.text.TextUtils
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Custom view that draws a weighted wheel and animates a spin.
 * Pointer sits at the top; angles are measured clockwise from the top.
 */
class WheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var entries: List<Entry> = emptyList()
        set(value) {
            field = value
            recompute()
            invalidate()
        }

    var durationMs: Long = 5000L
    var onTick: (() -> Unit)? = null
    var onResult: ((Int) -> Unit)? = null

    val isSpinning: Boolean get() = animator?.isRunning == true

    private var rot = 0f
    private var animator: ValueAnimator? = null
    private var cum = FloatArray(1)
    private var lastSeg = -1

    private val density = resources.displayMetrics.density
    private val rect = RectF()
    private val pointerPath = Path()

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2f * density
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#22242E")
        strokeWidth = 8f * density
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        isFakeBoldText = true
    }
    private val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val hubInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B1B22") }
    private val hubTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val pointerStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#22242E")
        strokeWidth = 2f * density
        strokeJoin = Paint.Join.ROUND
    }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#6B6E7B") }

    private val easeOutQuart = TimeInterpolator { t -> 1f - (1f - t).pow(4) }

    private fun recompute() {
        val n = entries.size
        cum = FloatArray(n + 1)
        val total = entries.sumOf { max(1, it.weight) }.toFloat()
        var acc = 0f
        for (i in 0 until n) {
            cum[i] = acc / total * 360f
            acc += max(1, entries[i].weight)
        }
        cum[n] = 360f
    }

    private fun pointerAngle(r: Float): Float = (((360f - r % 360f) % 360f) + 360f) % 360f

    private fun segmentAt(angle: Float): Int {
        val n = entries.size
        if (n == 0) return -1
        for (i in 0 until n) if (angle < cum[i + 1]) return i
        return n - 1
    }

    fun spin(): Boolean {
        if (isSpinning || entries.isEmpty()) return false
        // Prank: an entry named "Monza" always wins while it exists; otherwise fully random.
        val rigged = entries.indices.filter { entries[it].text.trim().equals("monza", ignoreCase = true) }
        val pick = if (rigged.isNotEmpty()) {
            val i = rigged.random()
            val margin = (cum[i + 1] - cum[i]) * 0.15f
            cum[i] + margin + Random.nextFloat() * (cum[i + 1] - cum[i] - 2 * margin)
        } else {
            Random.nextFloat() * 360f
        }
        val targetRot = (360f - pick) % 360f
        val cur = ((rot % 360f) + 360f) % 360f
        val delta = ((targetRot - cur) + 360f) % 360f
        val total = (5 + Random.nextInt(3)) * 360f + delta
        val startRot = rot
        lastSeg = segmentAt(pointerAngle(rot))

        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = easeOutQuart
            addUpdateListener {
                rot = startRot + total * (it.animatedValue as Float)
                val seg = segmentAt(pointerAngle(rot))
                if (seg != lastSeg) {
                    lastSeg = seg
                    onTick?.invoke()
                }
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    rot = ((rot % 360f) + 360f) % 360f
                    invalidate()
                    if (!cancelled) {
                        val idx = segmentAt(pointerAngle(rot))
                        if (idx >= 0) onResult?.invoke(idx)
                    }
                }
            })
            start()
        }
        return true
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    private fun contrastText(bg: Int): Int {
        val lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (lum > 0.62) Color.parseColor("#1B1B22") else Color.WHITE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width - paddingLeft - paddingRight
        val h = height - paddingTop - paddingBottom
        val size = min(w, h).toFloat()
        val cx = paddingLeft + w / 2f
        val cy = paddingTop + h / 2f + 8f * density
        val r = size / 2f - 14f * density
        if (r <= 0f) return
        rect.set(cx - r, cy - r, cx + r, cy + r)

        val n = entries.size
        if (n == 0) {
            canvas.drawCircle(cx, cy, r, emptyPaint)
        } else {
            canvas.save()
            canvas.rotate(rot, cx, cy)
            for (i in 0 until n) {
                val e = entries[i]
                val sweep = cum[i + 1] - cum[i]
                arcPaint.color = e.color
                canvas.drawArc(rect, -90f + cum[i], sweep, true, arcPaint)
                if (n > 1) canvas.drawArc(rect, -90f + cum[i], sweep, true, linePaint)
            }
            for (i in 0 until n) {
                val e = entries[i]
                val sweep = cum[i + 1] - cum[i]
                val mid = (cum[i] + cum[i + 1]) / 2f
                canvas.save()
                canvas.rotate(mid - 90f, cx, cy)
                textPaint.color = contrastText(e.color)
                val arcHeight = (2f * Math.PI.toFloat() * r * (sweep / 360f)) * 0.6f
                textPaint.textSize = min(r * 0.12f, max(arcHeight, 9f * density))
                val avail = r * 0.62f
                val label = TextUtils.ellipsize(e.text, textPaint, avail, TextUtils.TruncateAt.END).toString()
                val fm = textPaint.fontMetrics
                canvas.drawText(label, cx + r - 16f * density, cy - (fm.ascent + fm.descent) / 2f, textPaint)
                canvas.restore()
            }
            canvas.restore()
        }

        canvas.drawCircle(cx, cy, r, rimPaint)

        // hub
        val hubR = r * 0.17f
        canvas.drawCircle(cx, cy, hubR + 4f * density, hubPaint)
        canvas.drawCircle(cx, cy, hubR, hubInnerPaint)
        hubTextPaint.textSize = hubR * 0.62f
        val hfm = hubTextPaint.fontMetrics
        canvas.drawText(context.getString(R.string.spin), cx, cy - (hfm.ascent + hfm.descent) / 2f, hubTextPaint)

        // pointer (fixed at the top)
        val tipY = cy - r + 22f * density
        val topY = cy - r - 14f * density
        val half = 14f * density
        pointerPath.reset()
        pointerPath.moveTo(cx - half, topY)
        pointerPath.lineTo(cx + half, topY)
        pointerPath.lineTo(cx, tipY)
        pointerPath.close()
        canvas.drawPath(pointerPath, pointerPaint)
        canvas.drawPath(pointerPath, pointerStroke)
    }
}
