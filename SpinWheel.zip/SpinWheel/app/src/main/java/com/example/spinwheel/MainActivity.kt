package com.example.spinwheel

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var wheels: MutableList<Wheel>
    private lateinit var wheel: Wheel
    private lateinit var settings: Settings
    private lateinit var wheelView: WheelView
    private lateinit var titleView: TextView
    private lateinit var btnSpin: MaterialButton
    private lateinit var btnEdit: MaterialButton
    private lateinit var feedback: Feedback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wheelView = findViewById(R.id.wheel)
        titleView = findViewById(R.id.title)
        btnSpin = findViewById(R.id.btnSpin)
        btnEdit = findViewById(R.id.btnEdit)
        feedback = Feedback(this)

        wheelView.onTick = { feedback.tick() }
        wheelView.onResult = { index -> onWinner(index) }
        wheelView.setOnClickListener { startSpin() }
        btnSpin.setOnClickListener { startSpin() }
        btnEdit.setOnClickListener { openEditor() }
        titleView.setOnClickListener { openEditor() }
        findViewById<ImageButton>(R.id.btnWheels).setOnClickListener { showWheels() }
        findViewById<ImageButton>(R.id.btnHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
    }

    override fun onResume() {
        super.onResume()
        settings = Store.loadSettings(this)
        feedback.soundOn = settings.sound
        feedback.vibrateOn = settings.vibrate
        wheelView.durationMs = settings.durationSec * 1000L
        reload()
    }

    override fun onDestroy() {
        feedback.release()
        super.onDestroy()
    }

    private fun reload() {
        if (wheelView.isSpinning) return
        wheels = Store.loadWheels(this)
        val cur = Store.currentId(this)
        wheel = wheels.firstOrNull { it.id == cur } ?: wheels.first()
        Store.setCurrent(this, wheel.id)
        titleView.text = wheel.title
        wheelView.entries = wheel.entries
    }

    private fun setSpinning(spinning: Boolean) {
        btnSpin.isEnabled = !spinning
        btnEdit.isEnabled = !spinning
    }

    private fun startSpin() {
        if (wheel.entries.isEmpty()) return
        if (wheelView.spin()) setSpinning(true)
    }

    private fun openEditor() {
        if (wheelView.isSpinning) return
        startActivity(Intent(this, EditActivity::class.java).putExtra("id", wheel.id))
    }

    private fun onWinner(index: Int) {
        setSpinning(false)
        val entry = wheel.entries.getOrNull(index) ?: return
        feedback.win()
        Store.addHistory(this, HistoryItem(wheel.title, entry.text, System.currentTimeMillis()))

        val builder = AlertDialog.Builder(this)
            .setTitle(R.string.winner)
            .setMessage(entry.text)
            .setPositiveButton(R.string.spin_again) { _, _ -> startSpin() }
            .setNeutralButton(R.string.ok, null)
        builder.show()
    }

    private fun removeEntry(entry: Entry) {
        if (wheel.entries.size <= 2) return
        wheel.entries.remove(entry)
        Store.saveWheels(this, wheels)
        wheelView.entries = wheel.entries
    }

    private fun showWheels() {
        if (wheelView.isSpinning) return
        val titles = wheels.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.my_wheels)
            .setItems(titles) { _, which ->
                Store.setCurrent(this, wheels[which].id)
                reload()
            }
            .setNeutralButton(R.string.new_wheel) { _, _ -> showPresets() }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun showPresets() {
        AlertDialog.Builder(this)
            .setTitle(R.string.choose_preset)
            .setItems(Presets.names(this).toTypedArray()) { _, which ->
                val w = Presets.create(this, which)
                wheels.add(w)
                Store.saveWheels(this, wheels)
                Store.setCurrent(this, w.id)
                reload()
                if (which == 0) openEditor()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSettings() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        val swSound = v.findViewById<SwitchCompat>(R.id.swSound)
        val swVibrate = v.findViewById<SwitchCompat>(R.id.swVibrate)
        val swDark = v.findViewById<SwitchCompat>(R.id.swDark)
        val label = v.findViewById<TextView>(R.id.durationLabel)
        val seek = v.findViewById<SeekBar>(R.id.seekDuration)

        swSound.isChecked = settings.sound
        swVibrate.isChecked = settings.vibrate
        swDark.isChecked = settings.dark
        seek.progress = (settings.durationSec - 2).coerceIn(0, 8)
        label.text = getString(R.string.spin_duration, settings.durationSec)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = getString(R.string.spin_duration, p + 2)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        AlertDialog.Builder(this)
            .setTitle(R.string.settings)
            .setView(v)
            .setPositiveButton(R.string.save) { _, _ ->
                val darkChanged = swDark.isChecked != settings.dark
                settings = Settings(
                    sound = swSound.isChecked,
                    vibrate = swVibrate.isChecked,
                    durationSec = seek.progress + 2,
                    dark = swDark.isChecked
                )
                Store.saveSettings(this, settings)
                feedback.soundOn = settings.sound
                feedback.vibrateOn = settings.vibrate
                wheelView.durationMs = settings.durationSec * 1000L
                if (darkChanged) App.applyTheme(settings.dark)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
