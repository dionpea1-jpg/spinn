package com.example.spinwheel

import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Date

class HistoryActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            Store.saveHistory(this, emptyList())
            render()
        }
        render()
    }

    private fun render() {
        list.removeAllViews()
        val items = Store.loadHistory(this)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val fmt = DateFormat.getMediumDateFormat(this)
        val tfmt = DateFormat.getTimeFormat(this)
        items.forEach { h ->
            val row = layoutInflater.inflate(R.layout.item_history, list, false)
            row.findViewById<TextView>(R.id.result).text = h.result
            val d = Date(h.time)
            row.findViewById<TextView>(R.id.meta).text =
                "${h.wheelTitle} • ${fmt.format(d)} ${tfmt.format(d)}"
            list.addView(row)
        }
    }
}
