package com.example.spinwheel

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Sound + vibration helper. */
class Feedback(private val context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private val tickId = pool.load(context, R.raw.tick, 1)
    private val winId = pool.load(context, R.raw.win, 1)
    private var lastTick = 0L

    var soundOn = true
    var vibrateOn = true

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun tick() {
        if (!soundOn) return
        val now = System.currentTimeMillis()
        if (now - lastTick < 35) return
        lastTick = now
        pool.play(tickId, 0.6f, 0.6f, 1, 0, 1f)
    }

    fun win() {
        if (soundOn) pool.play(winId, 1f, 1f, 1, 0, 1f)
        if (vibrateOn) vibrate(120)
    }

    private fun vibrate(ms: Long) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    fun release() {
        pool.release()
    }
}
