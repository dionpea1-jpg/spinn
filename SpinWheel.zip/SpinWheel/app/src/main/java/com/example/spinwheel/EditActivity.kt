package com.example.spinwheel

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class EditActivity : AppCompatActivity() {

    private lateinit var wheels: MutableList<Wheel>
    private lateinit var wheel: Wheel
    private lateinit var list: LinearLayout
    private lateinit var titleEdit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        wheels = Store.loadWheels(this)
        val id = intent.getStringExtra("id")
        wheel = wheels.firstOrNull { it.id == id } ?: wheels.first()

        list = findViewById(R.id.list)
        titleEdit = findViewById(R.id.editTitle)
        titleEdit.setText(wheel.title)
        wheel.entries.forEach { addRow(Entry(it.text, it.color, it.weight), focus = false) }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { saveAndFinish() }
        findViewById<MaterialButton>(R.id.btnAdd).setOnClickListener {
            addRow(Entry("", Palette.at(list.childCount)), focus = true)
        }
        findViewById<ImageButton>(R.id.btnShuffle).setOnClickListener { shuffle() }
        findViewById<ImageButton>(R.id.btnDeleteWheel).setOnClickListener { confirmDelete() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = saveAndFinish()
        })
    }

    private fun currentEntries(): List<Entry> =
        (0 until list.childCount).map { list.getChildAt(it).tag as Entry }

    private fun addRow(e: Entry, focus: Boolean) {
        val row = layoutInflater.inflate(R.layout.item_entry, list, false)
        row.tag = e
        val dot = row.findViewById<View>(R.id.dot)
        val text = row.findViewById<EditText>(R.id.entryText)
        val weight = row.findViewById<TextView>(R.id.weight)

        fun paintDot() {
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(e.color)
            }
        }
        paintDot()
        weight.text = e.weight.toString()
        text.setText(e.text)
        text.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                e.text = s?.toString() ?: ""
            }
        })
        dot.setOnClickListener {
            e.color = Palette.next(e.color)
            paintDot()
        }
        row.findViewById<View>(R.id.btnMinus).setOnClickListener {
            if (e.weight > 1) {
                e.weight--
                weight.text = e.weight.toString()
            }
        }
        row.findViewById<View>(R.id.btnPlus).setOnClickListener {
            if (e.weight < 9) {
                e.weight++
                weight.text = e.weight.toString()
            }
        }
        row.findViewById<View>(R.id.btnRemove).setOnClickListener { list.removeView(row) }
        list.addView(row)

        if (focus) {
            text.requestFocus()
            text.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(text, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun shuffle() {
        val items = currentEntries().shuffled()
        list.removeAllViews()
        items.forEach { addRow(it, focus = false) }
    }

    /** Returns true if saved. Requires at least 2 non-blank options. */
    private fun save(): Boolean {
        val entries = currentEntries().filter { it.text.isNotBlank() }
        if (entries.size < 2) {
            Toast.makeText(this, R.string.min_entries, Toast.LENGTH_SHORT).show()
            return false
        }
        wheel.title = titleEdit.text.toString().trim().ifBlank { getString(R.string.untitled) }
        wheel.entries.clear()
        wheel.entries.addAll(entries.map { Entry(it.text.trim(), it.color, it.weight) })
        Store.saveWheels(this, wheels)
        return true
    }

    private fun saveAndFinish() {
        if (save()) finish()
    }

    private fun confirmDelete() {
        if (wheels.size <= 1) {
            Toast.makeText(this, R.string.cant_delete_last, Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_wheel_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                wheels.remove(wheel)
                Store.saveWheels(this, wheels)
                Store.setCurrent(this, wheels.first().id)
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
