package com.example.spinwheel

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Entry(var text: String, var color: Int, var weight: Int = 1)

data class Wheel(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    val entries: MutableList<Entry>
)

data class HistoryItem(val wheelTitle: String, val result: String, val time: Long)

data class Settings(
    var sound: Boolean = true,
    var vibrate: Boolean = true,
    var durationSec: Int = 5,
    var eliminate: Boolean = false,
    var dark: Boolean = true
)

object Palette {
    val colors = intArrayOf(
        Color.parseColor("#1FA85A"),
        Color.parseColor("#2F6FD0"),
        Color.parseColor("#D9363E"),
        Color.parseColor("#F2B53C"),
        Color.parseColor("#8E4FD0"),
        Color.parseColor("#19A7B8"),
        Color.parseColor("#E8702A"),
        Color.parseColor("#D64A9A")
    )

    fun at(i: Int): Int = colors[((i % colors.size) + colors.size) % colors.size]
    fun next(c: Int): Int {
        val idx = colors.indexOf(c)
        return at(idx + 1)
    }
}

object Presets {
    private fun build(title: String, items: List<String>): Wheel =
        Wheel(
            title = title,
            entries = items.mapIndexed { i, t -> Entry(t, Palette.at(i)) }.toMutableList()
        )

    fun blank(ctx: Context): Wheel =
        build(ctx.getString(R.string.untitled), listOf("", "").let {
            listOf(ctx.getString(R.string.entry_hint) + " 1", ctx.getString(R.string.entry_hint) + " 2")
        })

    fun names(ctx: Context): List<String> = listOf(
        ctx.getString(R.string.blank_wheel),
        ctx.getString(R.string.preset_yes_no),
        ctx.getString(R.string.preset_food),
        ctx.getString(R.string.preset_dice),
        ctx.getString(R.string.preset_coin),
        ctx.getString(R.string.preset_truth_dare),
        ctx.getString(R.string.preset_activity)
    )

    fun create(ctx: Context, index: Int): Wheel = when (index) {
        1 -> build(
            ctx.getString(R.string.preset_yes_no),
            listOf(ctx.getString(R.string.yes), ctx.getString(R.string.no))
        )
        2 -> build(
            ctx.getString(R.string.preset_food),
            listOf(
                R.string.food_pizza, R.string.food_burger, R.string.food_sushi,
                R.string.food_noodles, R.string.food_salad, R.string.food_tacos
            ).map { ctx.getString(it) }
        )
        3 -> build(ctx.getString(R.string.preset_dice), (1..6).map { it.toString() })
        4 -> build(
            ctx.getString(R.string.preset_coin),
            listOf(ctx.getString(R.string.heads), ctx.getString(R.string.tails))
        )
        5 -> build(
            ctx.getString(R.string.preset_truth_dare),
            listOf(ctx.getString(R.string.truth), ctx.getString(R.string.dare))
        )
        6 -> build(
            ctx.getString(R.string.preset_activity),
            listOf(
                R.string.act_walk, R.string.act_read, R.string.act_movie,
                R.string.act_cook, R.string.act_game, R.string.act_friend
            ).map { ctx.getString(it) }
        )
        else -> blank(ctx)
    }
}

object Store {
    private const val PREFS = "spin_wheel_store"
    private const val MAX_HISTORY = 200

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadWheels(c: Context): MutableList<Wheel> {
        val raw = prefs(c).getString("wheels", null)
        val out = mutableListOf<Wheel>()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val es = o.getJSONArray("entries")
                    val entries = mutableListOf<Entry>()
                    for (j in 0 until es.length()) {
                        val e = es.getJSONObject(j)
                        entries.add(Entry(e.getString("t"), e.getInt("c"), e.optInt("w", 1)))
                    }
                    out.add(Wheel(o.getString("id"), o.getString("title"), entries))
                }
            } catch (_: Exception) {
                out.clear()
            }
        }
        if (out.isEmpty()) {
            out.add(Presets.create(c, 2))
            out.add(Presets.create(c, 1))
            out.add(Presets.create(c, 3))
            saveWheels(c, out)
            setCurrent(c, out[0].id)
        }
        return out
    }

    fun saveWheels(c: Context, wheels: List<Wheel>) {
        val arr = JSONArray()
        wheels.forEach { w ->
            val es = JSONArray()
            w.entries.forEach {
                es.put(JSONObject().put("t", it.text).put("c", it.color).put("w", it.weight))
            }
            arr.put(JSONObject().put("id", w.id).put("title", w.title).put("entries", es))
        }
        prefs(c).edit().putString("wheels", arr.toString()).apply()
    }

    fun currentId(c: Context): String? = prefs(c).getString("current", null)
    fun setCurrent(c: Context, id: String) {
        prefs(c).edit().putString("current", id).apply()
    }

    fun loadHistory(c: Context): MutableList<HistoryItem> {
        val out = mutableListOf<HistoryItem>()
        val raw = prefs(c).getString("history", null) ?: return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(HistoryItem(o.getString("w"), o.getString("r"), o.getLong("t")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addHistory(c: Context, item: HistoryItem) {
        val list = loadHistory(c)
        list.add(0, item)
        saveHistory(c, list.take(MAX_HISTORY))
    }

    fun saveHistory(c: Context, list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("w", it.wheelTitle).put("r", it.result).put("t", it.time))
        }
        prefs(c).edit().putString("history", arr.toString()).apply()
    }

    fun loadSettings(c: Context): Settings {
        val p = prefs(c)
        return Settings(
            sound = p.getBoolean("s_sound", true),
            vibrate = p.getBoolean("s_vibrate", true),
            durationSec = p.getInt("s_duration", 5),
            eliminate = p.getBoolean("s_eliminate", false),
            dark = p.getBoolean("s_dark", true)
        )
    }

    fun saveSettings(c: Context, s: Settings) {
        prefs(c).edit()
            .putBoolean("s_sound", s.sound)
            .putBoolean("s_vibrate", s.vibrate)
            .putInt("s_duration", s.durationSec)
            .putBoolean("s_eliminate", s.eliminate)
            .putBoolean("s_dark", s.dark)
            .apply()
    }
}
